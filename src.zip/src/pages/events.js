import React from "react";

import Navbar from "@/components/Navbar";

const EventsPage = () => {
  return (
    <div >
      
      
      
    </div>
  );
};

export default EventsPage;