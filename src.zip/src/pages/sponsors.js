import React from "react";


const SponsorsPage = () => {
  return (
    <div>
      
    </div>
  );
};

export default SponsorsPage;