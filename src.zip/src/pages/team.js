import React from "react";


const TeamPage = () => {
  return (
    <div>
     
    </div>
  );
};

export default TeamPage;