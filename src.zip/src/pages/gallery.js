import React from 'react';

const gallery = () => {
  return (
    <div>
      
    </div>
  );
}

export default gallery;
